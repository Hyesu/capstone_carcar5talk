#Changelog

## 3.0

* Memset fix recommended by Dougie Lawson
* Fixes for Kernel 3.15+ from https://github.com/chrillomat/py-spidev
* Fixes for Python 3/2 compatibility.
* Added subclassing support - https://github.com/doceme/py-spidev/issues/10

## 2.0

Code sourced from http://elk.informatik.fh-augsburg.de/da/da-49/trees/pyap7k/lang/py-spi
and modified.

## Pre 2.0

spimodule.c originally uathored by Volker Thoms, 2009.
